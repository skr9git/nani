---
title: "Using WDT with WebLogic Kubernetes Operator"
date: 2019-02-23T17:19:24-05:00
draft: false
weight: 11
description: "Using WDT with WebLogic Kubernetes Operator."
---

For details, see the [Extract Domain Resource Tool]({{< relref "/userguide/tools/kubernetes.md" >}}).
