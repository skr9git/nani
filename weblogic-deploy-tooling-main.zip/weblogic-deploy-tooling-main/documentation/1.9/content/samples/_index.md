+++
title = "Samples"
date = 2019-02-22T15:27:54-05:00
weight = 3
pre = "<b>3. </b>"
+++


These typical use case scenarios show you how some common configurations can be represented in the model.

{{% children style="h4" description="true" %}}
